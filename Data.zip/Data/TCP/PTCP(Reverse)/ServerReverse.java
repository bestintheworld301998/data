import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.StringTokenizer;


public class ServerReverse {
	
	public static void main(String args[]) throws IOException
	{
		ServerSocket ss = new ServerSocket(4444);
		Socket s = ss.accept();
		DataInputStream dis = new DataInputStream(s.getInputStream());
		DataOutputStream dos = new DataOutputStream(s.getOutputStream());
		String inp;
		
		System.out.println("Receving String ");
		inp = dis.readUTF();
		
		System.out.println("Equation is "+inp);
		StringBuffer str = new StringBuffer(inp);
		str.reverse();
		String ans = str.toString();
		
		
		dos.writeUTF(ans);
		System.out.println("Sending answer ..");
		
	}

}
