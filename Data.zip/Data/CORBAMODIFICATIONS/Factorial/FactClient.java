// Client

import FactModule.*;
import org.omg.CosNaming.*;
import org.omg.CosNaming.NamingContextPackage.*;
import org.omg.CORBA.*;
import java.io.*;
import java.util.Scanner;

class FactClient
{
    
    static double num;
    public static void main(String args[])
    {
        Fact FactImpl=null;
        Scanner s = new Scanner(System.in);
        try
        {
            // initialize the ORB
            org.omg.CORBA.ORB orb = org.omg.CORBA.ORB.init(args,null);

            org.omg.CORBA.Object objRef = orb.resolve_initial_references("NameService");
            NamingContextExt ncRef = NamingContextExtHelper.narrow(objRef);
            
            String name = "Fact";
            FactImpl = FactHelper.narrow(ncRef.resolve_str(name));
	
	   		BufferedReader in=new BufferedReader(new InputStreamReader(System.in));

        	System.out.println("enter number:");
       	 	num=Double.parseDouble(in.readLine());
	
			double result=FactImpl.fact(num);
        
            System.out.println("result is "+result);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
}
