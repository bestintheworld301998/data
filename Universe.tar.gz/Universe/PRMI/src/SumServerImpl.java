import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class SumServerImpl extends UnicastRemoteObject implements SumServerIntf
{
	public SumServerImpl() throws RemoteException
	{
		
	}
	
	public int sum(int m,int n)throws RemoteException
	{
		return m+n;
	}
	public int mul(int m , int n)throws RemoteException
	{
		return m*n;
	}
	public String rev(String inp)throws RemoteException
	{
		StringBuffer str = new StringBuffer(inp);
		str.reverse();
		String ans = str.toString();
		return ans;
		
	}
	public int fact(int m) throws RemoteException
	{
		int fact = 1;
		for(int i=1;i<=m;i++)
		{
			fact = fact * i;
		}
		return fact;
	}
	
}
