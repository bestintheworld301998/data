import java.rmi.Naming;

public class SumServer{
	
	public static void main(String args[])
	{
		try
		{
			SumServerImpl s1 = new SumServerImpl();
			Naming.rebind("SUM-SERVER", s1);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
