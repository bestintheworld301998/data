import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Scanner;

public class ClientAdd {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		InetAddress ip=InetAddress.getLocalHost();
		DatagramSocket ds=new DatagramSocket();
		byte buf[]=null;
		while(true)
		{
			buf=new byte[65535];
			//System.out.println("Enter the equation= ");
			System.out.println("Enter the string to reverse= ");
			String eq=sc.nextLine();
			buf=eq.getBytes();
			DatagramPacket dpsend=new DatagramPacket(buf,buf.length,ip,1234);
			ds.send(dpsend);
			//System.out.println("Equation is ent to server for performing addition");
			buf=new byte[65535];
			DatagramPacket dpreceive=new DatagramPacket(buf,buf.length);
			ds.receive(dpreceive);
			System.out.println("Result received= "+new String(buf,0,buf.length));
			break;
		}
		ds.close();
		sc.close();

	}

}