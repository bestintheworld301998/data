import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.StringTokenizer;

public class server_add {

	public static void main(String [] args)throws IOException
	{
		ServerSocket ss=new ServerSocket(4444);
		Socket s=ss.accept();
		DataInputStream dis=new DataInputStream(s.getInputStream());
		DataOutputStream dos=new DataOutputStream(s.getOutputStream());

		String inp;
		System.out.println("Receiving equation.......");
		inp=dis.readUTF();

		System.out.println("Equation is: "+inp);
		int result;

		StringTokenizer st=new StringTokenizer(inp);
		int oper1=Integer.parseInt(st.nextToken());
		String op=st.nextToken();
		int oper2=Integer.parseInt(st.nextToken());

		result=oper1+oper2;
		dos.writeUTF(Integer.toString(result));
		System.out.println("Sending result.......");

				
	}

}
