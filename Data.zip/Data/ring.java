import java.io.IOException;
import java.util.Scanner;

public class ring {

	static int no;
	static int index;
	static int co;
	static int activelist[] = new int[10];
	
	public static void main(String args[])throws IOException
	{
		System.out.println("Enter number of processes : ");
		Scanner in = new Scanner(System.in);
		no = in.nextInt();
		System.out.println("Current Coordinator is "+no);
		System.out.println("Which process will initiate election ?");
		int ele = in.nextInt();
		System.out.println("Message is send from "+ele+" to "+no);
		System.out.println("Process "+no+" is crashed");
		System.out.println("Election is start..");
		elect(ele);
		System.out.println("Final Coordinator is :"+co);
	}

	static void elect(int ele) {
		// TODO Auto-generated method stub
		ele = ele - 1;
		co = ele;
		index = 0;
		for(int i=ele;i<(no-1);i++)
		{
			if(i == (no-1))
			{
				System.out.println("Election message is send from "+(i+1)+" to 1");
			}
			else
			{
				System.out.println("Election message is send from "+(i+1)+" to "+(i+2));
			}
			activelist[index] = i+1;
			index++;
			if((i+1)>co)
			{
				co = i+1;
			}
			System.out.print("(");
			for(int j=0;j<index;j++)
			{
				System.out.print(activelist[j]+" ");
			}
			System.out.print(")");
		}
		for(int i=0;i<ele;i++)
		{
		
			System.out.println("Election message is send from "+(i+1)+" to "+(i+2));
			activelist[index] = i+1;
			index++;
			if((i+1)>co)
			{
				co = i+1;
			}
			System.out.print("(");
			for(int j=0;j<index;j++)
			{
				System.out.print(activelist[j]+" ");
			}
			System.out.print(")");
		}
	}
	
}
