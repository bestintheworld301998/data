import ReverseModule.ReversePOA;
import java.lang.String;
class ReverseImpl extends ReversePOA
{
    ReverseImpl()
    {
        super();
        System.out.println("Reverse Object Created");
    }
 
    public int addition(int num1, int num2)
    {
	int add = 0;
	add = num1 + num2;
	return add;
    }
    public int sub(int num1, int num2)
    {
	int sub = 0;
	sub = num1 - num2;
	return sub;
    }
    public int mult(int num1, int num2)
    {
	int mult = 0;
	mult = num1 * num2;
	return mult;
    }
    public int div(int num1, int num2)
    {
	int div = 0;
	div = num1 / num2;
	return div;
    }


	
}

