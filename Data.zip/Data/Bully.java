import java.util.Scanner;

import javax.swing.plaf.synth.SynthStyle;

public class Bully {

	static int no;
	static int pno[] = new int[100];
	static int stat[] = new int[100];
	static int co;
	
	public static void main(String args[])
	{
		System.out.println("\n Enter the number of process: ");
		Scanner in = new Scanner(System.in);
		no = in.nextInt();
		int i;
		for(i=0;i<no;i++)
		{
			pno[i]=i+1;
			if(i == no-1)
			{
				stat[i] = 0;
				System.out.println("Process "+(i+1)+ " will be crashed :");
			}
			else
			{
				stat[i] = 1;
			}
			System.out.println("Process (pid) is "+(i+1));
			System.out.println("State of process is "+stat[i]);
		}
		System.out.println("\n\t Enter Election Process :");
		int ele = in.nextInt();
		System.out.println("Process "+ele+" detected the crash");
		elect(ele);
		System.out.println("Cordinator "+co+" has been detect crsah :");
		System.out.println("Final Coordinator is "+co);
	}

	static void elect(int ele) {
		// TODO Auto-generated method stub
		ele = ele - 1;
		co = ele + 1;
		for(int i=0;i<no;i++)
		{
			if(pno[ele] < pno[i])
			{
				System.out.println("Election message is send from "+(ele+1)+" to "+(i+1));
				if(stat[i] == 1)
				{
					System.out.println("Reply message is send from "+(i+1)+" to "+(ele+1));
					elect(i+1);
				}
			}
		}
	}
}
