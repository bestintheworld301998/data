import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
//import java.util.StringTokenizer;

public class ServerAdd {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		DatagramSocket ds=new DatagramSocket(1234);
		byte buf[]=null;
		while(true)
		{
			buf=new byte[65535];
			DatagramPacket dpreceive=new DatagramPacket(buf,buf.length);
			ds.receive(dpreceive);
			String s1=new String(buf,0,buf.length);
			s1=s1.trim();
			StringBuffer str=new StringBuffer(s1);
			str.reverse();
			String s2=str.toString();
			int port=dpreceive.getPort();
			buf=new byte[65535];
			//String s2=Integer.toString(fact);
			buf=s2.getBytes();
			DatagramPacket dpsend=new DatagramPacket(buf,buf.length,InetAddress.getLocalHost(),port);
			ds.send(dpsend);
			break;
		}
		ds.close();
	}

}