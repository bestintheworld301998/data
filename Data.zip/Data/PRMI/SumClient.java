import java.rmi.Naming;
import java.util.Scanner;

public class SumClient  {

	public static void main(String args[])
	{
		try
		{
			String sumServerURL = "rmi://" +args[0]+ "SUM-SERVER";
			SumServerIntf s =(SumServerIntf)Naming.lookup(sumServerURL);
			
//			System.out.println("First number is "+args[1]);
//			int m = Integer.valueOf(args[1]);
//			System.out.println("Second number is " +args[2]);
//			int n = Integer.valueOf(args[2]);
			Scanner sc = new Scanner(System.in);
			
			System.out.println("Enter String "+args[1]);
			String name = sc.nextLine();
			
//			System.out.println("The Sum is "+s.sum(m, n));
//			System.out.println("The Mul is "+s.mul(m, n));
//			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}



/*
Server


javac SumServerIntf.java
javac SumServerImpl.java
javac SumServer.java
java SumServer

Client

javac SumClient.java
java SumClient 127.0.0.1 4 7


Creating stubs and skeletons


rmic SumServerImpl
rmiregistry
*/
