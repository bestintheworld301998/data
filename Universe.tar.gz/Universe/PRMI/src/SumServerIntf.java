import java.rmi.Remote;
import java.rmi.RemoteException;

public interface SumServerIntf extends Remote
{
	int sum(int m,int n)throws RemoteException;
	int mul(int m, int n)throws RemoteException;
	int fact(int m)throws RemoteException;
	String rev(String name)throws RemoteException;
}
