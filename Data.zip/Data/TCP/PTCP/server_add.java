import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.StringTokenizer;


public class server_add {
	
	public static void main(String args[]) throws IOException
	{
		ServerSocket ss = new ServerSocket(4444);
		Socket s = ss.accept();
		DataInputStream dis = new DataInputStream(s.getInputStream());
		DataOutputStream dos = new DataOutputStream(s.getOutputStream());
		String inp;
		
		System.out.println("Receving Equation ");
		inp = dis.readUTF();
		
		System.out.println("Equation is "+inp);
		
		int fact = 1;;
		StringTokenizer st =  new StringTokenizer(inp);
		int number = Integer.parseInt(st.nextToken());
		
		for(int i =1; i<=number ;i++)
		{
			fact = fact * i;
		}
		
		dos.writeUTF(Integer.toString(fact));
		System.out.println("Sending answer ..");
		
	}

}
