Server


javac SumServerIntf.java
javac SumServerImpl.java
javac SumServer.java
java SumServer

Client

javac SumClient.java
java SumClient 127.0.0.1 4 7


Creating stubs and skeletons


rmic SumServerImpl
rmiregistry
