import FactModule.FactPOA;
import java.lang.String;
class FactImpl extends FactPOA
{
    FactImpl()
    {
        super();
        System.out.println("Factorial Object Created");
    }

    public double fact(double n)
   {
     double fact_ans = 0;
     int fact = 1;
     //
     for(int i=1;i<=n;i++)
     {
    	 fact = i * fact;
     }
     fact_ans = fact;
     return(fact_ans);
   }
}
