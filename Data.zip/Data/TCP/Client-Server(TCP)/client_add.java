import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Scanner;

public class client_add {

	public static void main(String[]args)throws IOException
	{
		InetAddress ip=InetAddress.getLocalHost();
		int port=4444;
		Socket s=new Socket(ip,port);
		DataInputStream dis=new DataInputStream(s.getInputStream());
		DataOutputStream dos=new DataOutputStream(s.getOutputStream());

		Scanner sc=new Scanner(System.in);

		System.out.println("Enter the equation:");
		String inp=sc.nextLine();
		System.out.println("Sending equation.......");
		dos.writeUTF(inp);

		String ans;
		System.out.println("Receiving Result.......");
		ans=dis.readUTF();

		System.out.println("Result is"+ans);
	}
}
