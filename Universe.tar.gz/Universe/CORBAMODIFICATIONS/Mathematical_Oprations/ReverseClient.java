// Client

import ReverseModule.*;
import org.omg.CosNaming.*;
import org.omg.CosNaming.NamingContextPackage.*;
import org.omg.CORBA.*;
import java.io.*;
import java.util.Scanner;

class ReverseClient
{
    
    public static void main(String args[])
    {
        Reverse ReverseImpl=null;
        
        try
        {
            // initialize the ORB
            org.omg.CORBA.ORB orb = org.omg.CORBA.ORB.init(args,null);

            org.omg.CORBA.Object objRef = orb.resolve_initial_references("NameService");
            NamingContextExt ncRef = NamingContextExtHelper.narrow(objRef);
            
            String name = "Mathematical Operation";
            ReverseImpl = ReverseHelper.narrow(ncRef.resolve_str(name));

            System.out.println("\n Enter first no: ");
  	    Scanner scanner = new Scanner(System.in);
	    int num1 = scanner.nextInt();
       	    
            System.out.println("\n Enter second no: ");
            int num2 = scanner.nextInt();

            int tempStr= ReverseImpl.addition(num1,num2); 
	    System.out.println("\n Addition of numbers: ");
            System.out.println(tempStr);
		
            int tempStr1= ReverseImpl.sub(num1,num2); 
	    System.out.println("\n Subtraction of numbers: ");
            System.out.println(tempStr1);

            int tempStr2= ReverseImpl.mult(num1,num2); 
	    System.out.println("\n Multiplication of numbers: ");
            System.out.println(tempStr2);
		
            int tempStr3= ReverseImpl.div(num1,num2); 
	    System.out.println("\n Division of numbers: ");
            System.out.println(tempStr3);
	   
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
}
